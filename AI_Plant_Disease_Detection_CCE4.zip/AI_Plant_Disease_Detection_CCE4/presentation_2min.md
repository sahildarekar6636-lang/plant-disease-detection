# 2-Minute CCE-4 Presentation
## AI-Based Plant Disease Detection System

Good morning respected teacher and my friends.

Today I am presenting my mini project, **AI-Based Plant Disease Detection System**.

The main aim of this project is to demonstrate how Artificial Intelligence can classify plant-leaf images.

First, the user uploads a photograph of a plant leaf into our application. The image is resized and processed. Then a Convolutional Neural Network, also called CNN, analyses the image and predicts which category it most closely matches from the categories used during training.

For this project, I use Python, TensorFlow, Keras and Streamlit. The model is trained using labelled plant-leaf images from the PlantVillage dataset.

The main AI concepts used are Machine Learning, Deep Learning, Image Processing and Image Classification.

Now I will demonstrate the project. I upload a sample leaf image and click on the Analyse Leaf button. The application displays the model's predicted category and its confidence score.

This project shows how AI can support agricultural research and help us explore plant-health screening.

However, this is only an educational prototype. Its prediction is not a confirmed diagnosis, and real crop treatment decisions should be made with guidance from agricultural experts.

Thank you.
