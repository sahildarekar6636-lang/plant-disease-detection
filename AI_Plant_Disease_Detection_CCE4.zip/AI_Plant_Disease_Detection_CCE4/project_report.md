# CCE-4 Mini Project Report
## AI-Based Plant Disease Detection Using Leaf Images

**Student Name:** ____________________  
**Roll Number:** ____________________  
**Class / Department:** ____________________  
**Subject:** Fundamentals of Artificial Intelligence  
**Submitted to:** ____________________  
**Date:** ____________________

## 1. Abstract
This project demonstrates how Artificial Intelligence can be used to classify plant-leaf images. A Convolutional Neural Network (CNN) is trained using labelled leaf images. A simple web application allows a user to upload an image and view the category predicted by the model. The project is an educational prototype and is not intended to replace agricultural experts.

## 2. Introduction
Plant diseases can affect crop growth and productivity. Examining leaf images with computer vision is one way to explore how AI may support early screening. This project uses image classification to recognise patterns learned from a labelled dataset.

## 3. Problem Statement
Manual identification of plant diseases can require experience. The project explores whether a trained AI model can classify a leaf image into one of the categories represented in its training data.

## 4. Objectives
- Understand a practical application of Artificial Intelligence.
- Prepare and classify plant-leaf images.
- Build and train a CNN model.
- Create a simple web interface for image upload and prediction.
- Demonstrate the model's output and limitations.

## 5. Dataset
The project uses the PlantVillage dataset. It contains labelled images of healthy and diseased leaves from multiple crops. The class-folder names are used as labels. Dataset source: https://github.com/spMohanty/PlantVillage-Dataset

## 6. Technologies Used
- Python
- TensorFlow and Keras
- Convolutional Neural Network (CNN)
- Streamlit
- NumPy and Pillow

## 7. Methodology
1. Collect labelled leaf images.
2. Arrange images into folders by category.
3. Resize images to 224 × 224 pixels.
4. Split the dataset into training and validation subsets.
5. Train the CNN using the Adam optimiser and categorical learning from image labels.
6. Evaluate the model on the validation subset.
7. Save the trained model and class names.
8. Load them in the Streamlit application for predictions.

## 8. AI Concepts
**Artificial Intelligence:** The broad field of building systems that perform tasks requiring intelligent pattern recognition.

**Machine Learning:** The model learns patterns from examples rather than using only manually written rules.

**Deep Learning:** A type of machine learning that uses neural networks with multiple layers.

**CNN:** A neural network designed to learn spatial features from images.

**Image Classification:** Assigning an input image to one of the known categories.

## 9. System Requirements
Software: Python, TensorFlow, Streamlit and a web browser.  
Hardware: Laptop/desktop; a GPU is helpful but not essential for a small demonstration.

## 10. Results
**Number of classes used:** __________  
**Training epochs completed:** __________  
**Validation accuracy shown by the program:** __________  
**Validation loss shown by the program:** __________  

Paste screenshots of the running application and sample predictions here. These results must be filled in after actually running the project.

## 11. Advantages
- Demonstrates a practical use of AI in agriculture.
- Gives a quick model prediction for supported image categories.
- Can be extended to more crop categories.
- Provides hands-on experience with image processing and deep learning.

## 12. Limitations
- The model can only classify categories represented in its training data.
- Dataset images may have simpler backgrounds than real farm photographs.
- Lighting, camera quality, leaf age and multiple diseases can affect predictions.
- A model score is not a confirmed diagnosis.

## 13. Future Scope
- Add more crops and locally collected field images.
- Evaluate the model on a separate real-world test set.
- Build a mobile-friendly interface.
- Consult agricultural specialists to validate any practical use.

## 14. Conclusion
The project demonstrates how CNN-based image classification can be applied to plant-leaf images. It provides a working educational prototype and helps explain AI, machine learning, deep learning and image processing. Further testing and expert validation would be needed before real-world agricultural use.

## 15. References
1. Mohanty, S. P., Hughes, D. P. and Salathé, M. (2016). “Using Deep Learning for Image-Based Plant Disease Detection.” Frontiers in Plant Science, 7.
2. PlantVillage dataset repository: https://github.com/spMohanty/PlantVillage-Dataset
3. TensorFlow documentation: https://www.tensorflow.org/
4. Streamlit documentation: https://docs.streamlit.io/
