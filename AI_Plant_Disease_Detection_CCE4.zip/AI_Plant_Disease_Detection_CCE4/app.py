import json
from pathlib import Path

import numpy as np
import streamlit as st
import tensorflow as tf
from PIL import Image

MODEL_PATH = Path("plant_disease_model.keras")
CLASSES_PATH = Path("class_names.json")
IMG_SIZE = (224, 224)

st.set_page_config(page_title="Plant Disease AI", page_icon="🌿", layout="centered")
st.title("🌿 AI-Based Plant Disease Detection")
st.write("Upload a clear photo of a single plant leaf. The trained model will classify it into one of its learned categories.")

st.warning(
    "Educational prototype only. This result is not a confirmed diagnosis or treatment recommendation. "
    "The model may be wrong, especially for photos taken outdoors or crops/classes not included in its training data."
)

@st.cache_resource
def load_model():
    model = tf.keras.models.load_model(MODEL_PATH)
    class_names = json.loads(CLASSES_PATH.read_text(encoding="utf-8"))
    return model, class_names

if not MODEL_PATH.exists() or not CLASSES_PATH.exists():
    st.error("The trained model files are missing.")
    st.markdown(
        "First follow the instructions in **README.md** to prepare the PlantVillage dataset "
        "and run `python train.py`. This creates `plant_disease_model.keras` and `class_names.json`."
    )
    st.stop()

try:
    model, class_names = load_model()
except Exception as exc:
    st.error(f"Could not load the model: {exc}")
    st.stop()

uploaded = st.file_uploader("Choose a leaf image", type=["jpg", "jpeg", "png"])

if uploaded:
    image = Image.open(uploaded).convert("RGB")
    st.image(image, caption="Uploaded leaf image", use_container_width=True)

    resized = image.resize(IMG_SIZE)
    arr = np.asarray(resized, dtype=np.float32) / 255.0
    arr = np.expand_dims(arr, axis=0)

    if st.button("🔍 Analyse leaf", type="primary"):
        with st.spinner("Analysing image..."):
            probabilities = model.predict(arr, verbose=0)[0]
        best_idx = int(np.argmax(probabilities))
        label = class_names[best_idx]
        confidence = float(probabilities[best_idx]) * 100

        st.subheader("Model output")
        st.metric("Predicted category", label.replace("___", " — ").replace("_", " "))
        st.metric("Model confidence", f"{confidence:.1f}%")
        st.caption("Confidence is the model's score, not the probability that a real plant has this disease.")

        st.write("Top 3 model categories")
        top_indices = np.argsort(probabilities)[::-1][:3]
        for idx in top_indices:
            st.write(f"**{class_names[int(idx)].replace('___', ' — ').replace('_', ' ')}**")
            st.progress(float(probabilities[int(idx)]))

        st.info(
            "For real crop concerns, compare with reliable agricultural guidance or consult a local "
            "agriculture expert. Do not apply pesticides or other treatments based only on this demo."
        )
