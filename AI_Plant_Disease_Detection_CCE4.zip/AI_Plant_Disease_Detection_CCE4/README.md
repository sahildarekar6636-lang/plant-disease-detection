# AI-Based Plant Disease Detection — CCE-4

A student educational prototype that classifies plant-leaf photographs into the categories learned from the training dataset. It uses a Convolutional Neural Network (CNN) built with TensorFlow/Keras and a Streamlit interface.

**Important:** This is not a field-validated diagnostic tool. It may make mistakes and must not be used alone to decide crop treatment or pesticide use.

## 1. Project structure

```text
plant_disease_ai_cce4/
├── app.py
├── train.py
├── requirements.txt
├── README.md
├── project_report.md
└── presentation_2min.md
```

After training, two more files are created:
- `plant_disease_model.keras`
- `class_names.json`

## 2. Dataset

Use the PlantVillage leaf-image dataset. The original dataset repository describes colour, grayscale and segmented image versions:

https://github.com/spMohanty/PlantVillage-Dataset

The dataset includes multiple crop/disease categories. Download the dataset yourself and check the source's usage terms before redistributing images.

Arrange the extracted colour images like this:

```text
PlantVillage/
├── Apple___Apple_scab/
│   ├── image1.jpg
│   └── ...
├── Apple___Black_rot/
│   ├── image1.jpg
│   └── ...
├── Tomato___healthy/
│   ├── image1.jpg
│   └── ...
└── ...
```

The folder names become the model's class labels. You may start with a smaller subset of classes to reduce training time, but keep at least two categories and include a healthy category if available.

## 3. Run the project

Use a computer with Python installed. Training is easier in Google Colab if your computer does not have enough memory or processing power.

Install dependencies:

```bash
pip install -r requirements.txt
```

Train the model:

```bash
python train.py
```

Training creates `plant_disease_model.keras` and `class_names.json`.

Start the web app:

```bash
streamlit run app.py
```

Streamlit will show a local web address. Open it in your browser, upload a leaf image from one of the supported classes, and press **Analyse leaf**.

## 4. How the AI works

1. The image is resized to 224 × 224 pixels.
2. Pixel values are scaled to the 0–1 range.
3. CNN convolution layers learn visual patterns such as edges, spots, colour regions and textures.
4. Pooling layers reduce the feature-map size.
5. A dense output layer with softmax gives a score for each training category.
6. The app displays the category with the highest score and the top three scores.

## 5. Evaluation

The training script prints validation accuracy and validation loss. Record the actual values from your run in the project report. Do not claim a fixed accuracy before training.

For a stronger evaluation, test with separate images that were not used for training. Photos from real farms may differ from the clean dataset backgrounds and can produce incorrect predictions.

## 6. Troubleshooting

- **Dataset not found:** Make sure the folder is named exactly `PlantVillage` and contains class folders directly inside it.
- **Model files missing:** Run `python train.py` successfully before starting Streamlit.
- **Training is slow:** Use Google Colab with a GPU runtime, or train with fewer classes and images for a classroom demo.
- **Prediction seems wrong:** Use a clear, well-lit image of one leaf, and check whether its class was included in training.

## 7. Academic note

Dataset reference: Mohanty, Hughes and Salathé (2016), “Using Deep Learning for Image-Based Plant Disease Detection,” Frontiers in Plant Science, 7. Cite the dataset and paper in your submission.
