import json
from pathlib import Path

import tensorflow as tf
from tensorflow.keras import layers, models

DATA_DIR = Path("PlantVillage")
IMG_SIZE = (224, 224)
BATCH_SIZE = 32
EPOCHS = 12
SEED = 42

if not DATA_DIR.exists():
    raise SystemExit(
        "Dataset folder 'PlantVillage' not found. Read README.md and place the "
        "extracted class folders inside a folder named PlantVillage."
    )

train_ds = tf.keras.utils.image_dataset_from_directory(
    DATA_DIR,
    validation_split=0.2,
    subset="training",
    seed=SEED,
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
)
val_ds = tf.keras.utils.image_dataset_from_directory(
    DATA_DIR,
    validation_split=0.2,
    subset="validation",
    seed=SEED,
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
)

class_names = train_ds.class_names
Path("class_names.json").write_text(json.dumps(class_names, indent=2), encoding="utf-8")

AUTOTUNE = tf.data.AUTOTUNE
train_ds = train_ds.cache().shuffle(1000).prefetch(buffer_size=AUTOTUNE)
val_ds = val_ds.cache().prefetch(buffer_size=AUTOTUNE)

num_classes = len(class_names)

data_augmentation = tf.keras.Sequential([
    layers.RandomFlip("horizontal"),
    layers.RandomRotation(0.08),
    layers.RandomZoom(0.1),
])

model = models.Sequential([
    layers.Input(shape=(*IMG_SIZE, 3)),
    data_augmentation,
    layers.Rescaling(1.0 / 255),
    layers.Conv2D(32, 3, activation="relu"),
    layers.MaxPooling2D(),
    layers.Conv2D(64, 3, activation="relu"),
    layers.MaxPooling2D(),
    layers.Conv2D(128, 3, activation="relu"),
    layers.MaxPooling2D(),
    layers.GlobalAveragePooling2D(),
    layers.Dropout(0.3),
    layers.Dense(128, activation="relu"),
    layers.Dense(num_classes, activation="softmax"),
])

model.compile(
    optimizer="adam",
    loss="sparse_categorical_crossentropy",
    metrics=["accuracy"],
)

callbacks = [
    tf.keras.callbacks.EarlyStopping(
        monitor="val_loss", patience=3, restore_best_weights=True
    )
]

model.summary()
history = model.fit(
    train_ds,
    validation_data=val_ds,
    epochs=EPOCHS,
    callbacks=callbacks,
)

loss, accuracy = model.evaluate(val_ds, verbose=0)
print(f"Validation accuracy: {accuracy * 100:.2f}%")
print(f"Validation loss: {loss:.4f}")
print("Use the measured validation accuracy in your report; do not guess or invent it.")

model.save("plant_disease_model.keras")
print("Saved plant_disease_model.keras and class_names.json")
